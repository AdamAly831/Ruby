require 'test_helper'

class NumberHelperTest < ActionView::TestCase
end
