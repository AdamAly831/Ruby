require 'test_helper'

class WordsHelperTest < ActionView::TestCase
end
